"""RAG modules for materials science."""
