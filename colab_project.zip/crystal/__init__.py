"""Crystal structure modules."""
