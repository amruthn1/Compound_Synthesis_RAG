"""Synthesis modules."""
