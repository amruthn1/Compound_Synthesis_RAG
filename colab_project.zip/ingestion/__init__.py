"""Ingestion modules for materials RAG system."""
