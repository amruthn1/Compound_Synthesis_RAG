"""Property prediction modules."""
